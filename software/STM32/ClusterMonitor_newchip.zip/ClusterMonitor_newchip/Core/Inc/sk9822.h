#ifndef SK9822_H
#define SK9822_H

#define LED_COUNT 200
#include "main.h"
#include "stdint.h"

union
{
	uint32_t frame;
	struct
	{
		uint8_t init_brightness ;
		uint8_t green			;
		uint8_t red				;
		uint8_t blue			;
	}packet;
}_led_frame[LED_COUNT];

void initORclear_allPixel(void);
void set_pixel(uint32_t color, int32_t led);
void set_brightness(uint8_t brightness, int32_t led);
void update_matrix(SPI_HandleTypeDef *_spiHandler);
uint32_t rgb2hex(uint8_t red, uint8_t green, uint8_t blue);
uint32_t hsv2hex(uint16_t h, double s, double v);

#endif
