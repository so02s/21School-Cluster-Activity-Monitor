#include "sk9822.h"

void initORclear_allPixel(void)
{
	for (int i = 0; i < LED_COUNT; i++)
	{
		_led_frame[i].packet.init_brightness = 0b11100000;
		_led_frame[i].packet.green = 0b00000000;
		_led_frame[i].packet.red = 0b00000000;
		_led_frame[i].packet.blue = 0b00000000;
	}
}

void set_pixel(uint32_t color, int32_t led)
{
	if (led == -1)
	{
		for (int i = 0; i < LED_COUNT; i++)
		{
			_led_frame[i].packet.red = (color >> 16) & 0b11111111;
			_led_frame[i].packet.green = (color >> 8) & 0b11111111;
			_led_frame[i].packet.blue = color & 0b11111111;
		}
	}
	else
	{
		_led_frame[led - 1].packet.red = (color >> 16) & 0b11111111;
		_led_frame[led - 1].packet.green = (color >> 8) & 0b11111111;
		_led_frame[led - 1].packet.blue = color & 0b11111111;
	}
}

uint32_t rgb2hex(uint8_t red, uint8_t green, uint8_t blue)
{
	uint32_t color;

	color = 0;
	color |= green << 16;
	color |= blue << 8;
	color |= red;
	return (color);
}

// h 0-360, s 0-1, v 0-1
uint32_t hsv2hex(uint16_t h, double s, double v)
{
    double      hh, p, q, t, ff;
    long        i;
    uint32_t	color = 0;

    if(s <= 0.0) {       // < is bogus, just shuts up warnings
    	color |= (uint8_t)(v*255) << 16;
    	color |= (uint8_t)(v*255) << 8;
    	color |= (uint8_t)(v*255);
        return color;
    }
    hh = h;
    if(hh >= 360.0) hh = 0.0;
    hh /= 60.0;
    i = (long)hh;
    ff = hh - i;
    p = v * (1.0 - s);
    q = v * (1.0 - (s * ff));
    t = v * (1.0 - (s * (1.0 - ff)));

    switch(i) {
    case 0:
        color |= (uint8_t)(v*255);
        color |= (uint8_t)(t*255) << 16;
        color |= (uint8_t)(p*255) << 8;
        break;
    case 1:
    	color |= (uint8_t)(q*255);
    	color |= (uint8_t)(v*255) << 16;
    	color |= (uint8_t)(p*255) << 8;
        break;
    case 2:
        color |= (uint8_t)(q*255);
        color |= (uint8_t)(v*255) << 16;
        color |= (uint8_t)(t*255) << 8;
        break;
    case 3:
        color |= (uint8_t)(p*255);
        color |= (uint8_t)(q*255) << 16;
        color |= (uint8_t)(v*255) << 8;
        break;
    case 4:
        color |= (uint8_t)(t*255);
        color |= (uint8_t)(p*255) << 16;
        color |= (uint8_t)(v*255) << 8;
        break;
    case 5:
    default:
        color |= (uint8_t)(v*255);
        color |= (uint8_t)(p*255) << 16;
        color |= (uint8_t)(q*255) << 8;
        break;
    }
    return color;
}

void set_brightness(uint8_t brightness, int32_t led)
{
	if (led != 0)
	{
		if (led == -1)
		{
			for (int i = 0; i < LED_COUNT; i++)
				_led_frame[i].packet.init_brightness |= brightness & 0b00011111;
		}
		else
		{
			_led_frame[led - 1].packet.init_brightness |= brightness & 0b00011111;
		}
	}
}

void update_matrix(SPI_HandleTypeDef *_spiHandler)
{
	int i = 0;
	int k = 0;

	k = (LED_COUNT + 1) / 16;
	if (k == 0)
		k = 1;
	uint8_t SPI_send[(LED_COUNT + 1)*4 + 4 + k];

	//start of frame its 32 bits of 0
	SPI_send[0] = 0b00000000;
	SPI_send[1] = 0b00000000;
	SPI_send[2] = 0b00000000;
	SPI_send[3] = 0b00000000;

	//main frame data
	int j = 0;
	for (i = 1; i < LED_COUNT + 1; i++)
	{
		SPI_send[i*4] = _led_frame[j].packet.init_brightness;
		SPI_send[i*4 + 1] = _led_frame[j].packet.green;
		SPI_send[i*4 + 2] = _led_frame[j].packet.red;
		SPI_send[i*4 + 3] = _led_frame[j].packet.blue;
		j++;
	}

	//end of frame its k bits of 0
	while (k > 0)
		SPI_send[i*4 + --k] = 0b00000000;

	HAL_SPI_Transmit(_spiHandler, SPI_send, (LED_COUNT + 1)*4 + 4 + k, 2); //<-- if led not work correctly maybe reason for this in timeout duration (it have to do with baudrate)
}
